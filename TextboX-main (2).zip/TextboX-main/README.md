# TextboX
Textbox is a simple Messaging app with a simple and intuitive design using the Open Fire Base Api
